import org.junit.*;

public class MyTest {
    @Test
    public void test_method_1() {
    }

    @Test
    public void test_method_2() {
    }
}